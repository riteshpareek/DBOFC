-- =====================================================================
-- Database-Side Data Obfuscation Framework
-- Target: MariaDB
-- Assumes: this script runs against the LOWER-ENVIRONMENT COPY only,
--          after the production->lower copy has completed.
-- Assumes: dap_User.UserID *is* the email address (per spec section 1).
--          Adjust column names below if your actual schema differs.
-- =====================================================================

-- Run this against the target schema, e.g.:
--   USE Appian;

-- ---------------------------------------------------------------------
-- 0. CONFIGURATION SCHEMA
-- ---------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS ObfuscationConfig (
    ConfigID          BIGINT AUTO_INCREMENT PRIMARY KEY,
    TableName         VARCHAR(128) NOT NULL,
    ColumnName        VARCHAR(128) NOT NULL,
    ObfuscationType   VARCHAR(50)  NOT NULL,   -- FIRST_NAME | LAST_NAME | PHONE | ADDRESS | EMAIL | STATIC | HASH
    StaticValue       VARCHAR(255) NULL,       -- used when ObfuscationType = STATIC
    Enabled           BOOLEAN      NOT NULL DEFAULT TRUE,
    UNIQUE KEY UK_ObfuscationConfig (TableName, ColumnName)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS UserReferenceRegistry (
    RegistryID        BIGINT AUTO_INCREMENT PRIMARY KEY,
    TableName         VARCHAR(128) NOT NULL,
    ColumnName        VARCHAR(128) NOT NULL,
    DiscoveryMethod   VARCHAR(30)  NOT NULL,   -- FOREIGN_KEY | NAMING_CONVENTION | MANUAL
    ConstraintName    VARCHAR(128) NULL,
    Enabled           BOOLEAN      NOT NULL DEFAULT TRUE,
    UNIQUE KEY UK_UserReferenceRegistry (TableName, ColumnName)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS UserObfuscationMapping (
    OriginalUserID    VARCHAR(255) NOT NULL,
    ObfuscatedUserID  VARCHAR(255) NOT NULL,
    CreatedDate       DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (OriginalUserID),
    UNIQUE KEY UK_ObfuscatedUserID (ObfuscatedUserID)
) ENGINE=InnoDB;

-- Captures FK definitions so they can be dropped and restored exactly.
CREATE TABLE IF NOT EXISTS FkConstraintBackup (
    BackupID              BIGINT AUTO_INCREMENT PRIMARY KEY,
    ConstraintName        VARCHAR(128)  NOT NULL,
    TableName             VARCHAR(128)  NOT NULL,
    ColumnList            VARCHAR(1024) NOT NULL,   -- ordinal-ordered, comma separated
    ReferencedTableName   VARCHAR(128)  NOT NULL,
    ReferencedColumnList  VARCHAR(1024) NOT NULL,
    UpdateRule            VARCHAR(20)   NOT NULL,
    DeleteRule            VARCHAR(20)   NOT NULL,
    DroppedDate           DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    RestoredDate          DATETIME      NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS ObfuscationRunLog (
    LogID        BIGINT AUTO_INCREMENT PRIMARY KEY,
    RunID        CHAR(36)     NOT NULL,
    StepName     VARCHAR(100) NOT NULL,
    StepStatus   VARCHAR(20)  NOT NULL,   -- START | OK | SKIP | ERROR
    Message      VARCHAR(1000) NULL,
    LoggedAt     DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- Synthetic seed data (extend freely; SeedID must be a contiguous 0..N-1 range)
CREATE TABLE IF NOT EXISTS SyntheticFirstName (
    SeedID     INT PRIMARY KEY,
    NameValue  VARCHAR(50) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS SyntheticLastName (
    SeedID     INT PRIMARY KEY,
    NameValue  VARCHAR(50) NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS SyntheticStreetAddress (
    SeedID        INT PRIMARY KEY,
    AddressValue  VARCHAR(255) NOT NULL
) ENGINE=InnoDB;

-- Minimal seed sets — extend as needed for better distribution.
INSERT IGNORE INTO SyntheticFirstName (SeedID, NameValue) VALUES
 (0,'David'),(1,'Sarah'),(2,'Michael'),(3,'Emma'),(4,'James'),(5,'Olivia'),
 (6,'Daniel'),(7,'Sophie'),(8,'Ryan'),(9,'Grace'),(10,'Thomas'),(11,'Chloe'),
 (12,'Andrew'),(13,'Hannah'),(14,'Matthew'),(15,'Ella'),(16,'Joshua'),(17,'Lily'),
 (18,'Nathan'),(19,'Zoe');

INSERT IGNORE INTO SyntheticLastName (SeedID, NameValue) VALUES
 (0,'Williams'),(1,'Brown'),(2,'Taylor'),(3,'Anderson'),(4,'Clark'),(5,'Mitchell'),
 (6,'Campbell'),(7,'Stewart'),(8,'Morris'),(9,'Rogers'),(10,'Reed'),(11,'Cook'),
 (12,'Bell'),(13,'Murphy'),(14,'Bailey'),(15,'Cooper'),(16,'Richardson'),(17,'Foster'),
 (18,'Hughes'),(19,'Price');

INSERT IGNORE INTO SyntheticStreetAddress (SeedID, AddressValue) VALUES
 (0,'12 Wattle Street'),(1,'45 Banksia Road'),(2,'8 Coral Avenue'),(3,'21 Marigold Lane'),
 (4,'67 Grevillea Court'),(5,'3 Boronia Place'),(6,'19 Acacia Drive'),(7,'55 Hakea Crescent'),
 (8,'27 Melaleuca Way'),(9,'14 Bottlebrush Street');

-- ---------------------------------------------------------------------
-- 1. HELPER FUNCTIONS
-- ---------------------------------------------------------------------

DELIMITER $$

-- Safely backtick-quotes an identifier that ultimately comes only from
-- information_schema / trusted config tables (never from raw user input).
CREATE OR REPLACE FUNCTION fn_quote_identifier(p_identifier VARCHAR(128))
RETURNS VARCHAR(132)
DETERMINISTIC
BEGIN
    RETURN CONCAT('`', REPLACE(p_identifier, '`', '``'), '`');
END$$

-- Deterministic, salted, collision-resistant obfuscated email generator.
-- p_local_part_len lets the caller fit the result to the real column's
-- character_maximum_length (see sp_create_user_mapping).
CREATE OR REPLACE FUNCTION fn_generate_obfuscated_email(
    p_original_email  VARCHAR(255),
    p_salt            VARCHAR(64),
    p_attempt         INT,
    p_local_part_len  INT
)
RETURNS VARCHAR(255)
DETERMINISTIC
BEGIN
    DECLARE v_hash VARCHAR(64);
    DECLARE v_local VARCHAR(64);

    -- p_attempt only changes on a mapping-table unique-key collision retry
    -- (astronomically unlikely with SHA-256, but handled rather than assumed away).
    SET v_hash = SHA2(CONCAT(p_salt, '|', LOWER(p_original_email), '|', p_attempt), 256);

    IF p_local_part_len < 8 THEN
        SET p_local_part_len = 8; -- floor to keep collision risk sane
    END IF;

    SET v_local = LOWER(SUBSTRING(v_hash, 1, LEAST(p_local_part_len, 40)));

    RETURN CONCAT(v_local, '@example.invalid');
END$$

-- Deterministic synthetic FIRST name, keyed by the user's identity (not
-- by the raw name value) so users sharing a real first name don't
-- necessarily collapse onto the same synthetic identity.
CREATE OR REPLACE FUNCTION fn_synthetic_first_name(p_user_key VARCHAR(255))
RETURNS VARCHAR(50)
NOT DETERMINISTIC READS SQL DATA
BEGIN
    DECLARE v_count INT;
    DECLARE v_idx INT;
    DECLARE v_result VARCHAR(50);

    SELECT COUNT(*) INTO v_count FROM SyntheticFirstName;
    IF v_count = 0 THEN
        RETURN 'Person';
    END IF;

    SET v_idx = CRC32(SHA2(CONCAT('fname|', p_user_key), 256)) MOD v_count;
    SELECT NameValue INTO v_result FROM SyntheticFirstName WHERE SeedID = v_idx;
    RETURN v_result;
END$$

CREATE OR REPLACE FUNCTION fn_synthetic_last_name(p_user_key VARCHAR(255))
RETURNS VARCHAR(50)
NOT DETERMINISTIC READS SQL DATA
BEGIN
    DECLARE v_count INT;
    DECLARE v_idx INT;
    DECLARE v_result VARCHAR(50);

    SELECT COUNT(*) INTO v_count FROM SyntheticLastName;
    IF v_count = 0 THEN
        RETURN 'Surname';
    END IF;

    SET v_idx = CRC32(SHA2(CONCAT('lname|', p_user_key), 256)) MOD v_count;
    SELECT NameValue INTO v_result FROM SyntheticLastName WHERE SeedID = v_idx;
    RETURN v_result;
END$$

CREATE OR REPLACE FUNCTION fn_synthetic_street_address(p_user_key VARCHAR(255))
RETURNS VARCHAR(255)
NOT DETERMINISTIC READS SQL DATA
BEGIN
    DECLARE v_count INT;
    DECLARE v_idx INT;
    DECLARE v_result VARCHAR(255);

    SELECT COUNT(*) INTO v_count FROM SyntheticStreetAddress;
    IF v_count = 0 THEN
        RETURN '1 Example Street';
    END IF;

    SET v_idx = CRC32(SHA2(CONCAT('addr|', p_user_key), 256)) MOD v_count;
    SELECT AddressValue INTO v_result FROM SyntheticStreetAddress WHERE SeedID = v_idx;
    RETURN v_result;
END$$

-- Deterministic synthetic phone number. Fixed Australian-style mobile
-- format shown as an example — adjust the literal pattern for your locale.
CREATE OR REPLACE FUNCTION fn_synthetic_phone(p_user_key VARCHAR(255), p_max_len INT)
RETURNS VARCHAR(50)
DETERMINISTIC
BEGIN
    DECLARE v_hash BIGINT UNSIGNED;
    DECLARE v_digits VARCHAR(20);
    DECLARE v_result VARCHAR(50);

    SET v_hash = CONV(SUBSTRING(SHA2(CONCAT('phone|', p_user_key), 256), 1, 8), 16, 10);
    SET v_digits = LPAD(v_hash MOD 100000000, 8, '0');
    SET v_result = CONCAT('04', v_digits);

    IF p_max_len IS NOT NULL AND p_max_len > 0 AND LENGTH(v_result) > p_max_len THEN
        SET v_result = LEFT(v_result, p_max_len);
    END IF;

    RETURN v_result;
END$$

DELIMITER ;

-- ---------------------------------------------------------------------
-- 2. LOGGING HELPER
-- ---------------------------------------------------------------------

DELIMITER $$
CREATE OR REPLACE PROCEDURE sp_log_step(
    IN p_run_id CHAR(36), IN p_step VARCHAR(100),
    IN p_status VARCHAR(20), IN p_message VARCHAR(1000)
)
BEGIN
    INSERT INTO ObfuscationRunLog (RunID, StepName, StepStatus, Message)
    VALUES (p_run_id, p_step, p_status, p_message);
END$$
DELIMITER ;

-- ---------------------------------------------------------------------
-- 3. sp_validate_config
--    Sanity-checks ObfuscationConfig against live metadata before
--    anything destructive happens.
-- ---------------------------------------------------------------------

DELIMITER $$
CREATE OR REPLACE PROCEDURE sp_validate_config(IN p_run_id CHAR(36))
BEGIN
    DECLARE v_missing INT;

    SELECT COUNT(*) INTO v_missing
    FROM ObfuscationConfig oc
    LEFT JOIN information_schema.COLUMNS c
        ON c.TABLE_SCHEMA = DATABASE()
       AND c.TABLE_NAME  = oc.TableName
       AND c.COLUMN_NAME = oc.ColumnName
    WHERE oc.Enabled = TRUE
      AND c.COLUMN_NAME IS NULL;

    IF v_missing > 0 THEN
        CALL sp_log_step(p_run_id, 'sp_validate_config', 'ERROR',
            CONCAT(v_missing, ' ObfuscationConfig row(s) reference columns that do not exist in the current schema.'));
        SELECT oc.TableName, oc.ColumnName
        FROM ObfuscationConfig oc
        LEFT JOIN information_schema.COLUMNS c
            ON c.TABLE_SCHEMA = DATABASE()
           AND c.TABLE_NAME  = oc.TableName
           AND c.COLUMN_NAME = oc.ColumnName
        WHERE oc.Enabled = TRUE AND c.COLUMN_NAME IS NULL;
        SIGNAL SQLSTATE '45000'
            SET MESSAGE_TEXT = 'ObfuscationConfig references non-existent columns. Fix config before proceeding.';
    ELSE
        CALL sp_log_step(p_run_id, 'sp_validate_config', 'OK', 'All configured columns exist.');
    END IF;
END$$
DELIMITER ;

-- ---------------------------------------------------------------------
-- 4. sp_discover_user_references
--    Populates UserReferenceRegistry from FK metadata + naming
--    convention. Re-runnable: refreshes rather than duplicates.
-- ---------------------------------------------------------------------

DELIMITER $$
CREATE OR REPLACE PROCEDURE sp_discover_user_references(IN p_run_id CHAR(36))
BEGIN
    -- 4a. True foreign keys pointing at dap_User.UserID
    INSERT INTO UserReferenceRegistry (TableName, ColumnName, DiscoveryMethod, ConstraintName)
    SELECT
        kcu.TABLE_NAME, kcu.COLUMN_NAME, 'FOREIGN_KEY', kcu.CONSTRAINT_NAME
    FROM information_schema.KEY_COLUMN_USAGE kcu
    WHERE kcu.TABLE_SCHEMA = DATABASE()
      AND kcu.REFERENCED_TABLE_SCHEMA = DATABASE()
      AND kcu.REFERENCED_TABLE_NAME = 'dap_User'
      AND kcu.REFERENCED_COLUMN_NAME = 'UserID'
    ON DUPLICATE KEY UPDATE
        DiscoveryMethod = 'FOREIGN_KEY',
        ConstraintName  = VALUES(ConstraintName),
        Enabled = TRUE;

    -- 4b. Naming-convention columns (CreatedBy, ModifiedBy, etc.) that are
    -- NOT already captured as an FK above — these are value copies, not
    -- enforced relationships, so they need a separate discovery path.
    INSERT INTO UserReferenceRegistry (TableName, ColumnName, DiscoveryMethod, ConstraintName)
    SELECT
        cc.TABLE_NAME, cc.COLUMN_NAME, 'NAMING_CONVENTION', NULL
    FROM information_schema.COLUMNS cc
    JOIN information_schema.TABLES tt
        ON tt.TABLE_SCHEMA = cc.TABLE_SCHEMA AND tt.TABLE_NAME = cc.TABLE_NAME
    WHERE cc.TABLE_SCHEMA = DATABASE()
      AND tt.TABLE_TYPE = 'BASE TABLE'
      AND cc.COLUMN_NAME IN ('CreatedBy','CreatedUser','CreatedUserID','ModifiedBy','ModifiedUserID')
      AND NOT EXISTS (
          SELECT 1 FROM UserReferenceRegistry r
          WHERE r.TableName = cc.TABLE_NAME AND r.ColumnName = cc.COLUMN_NAME
      )
    ON DUPLICATE KEY UPDATE Enabled = TRUE;

    CALL sp_log_step(p_run_id, 'sp_discover_user_references', 'OK',
        (SELECT CONCAT(COUNT(*), ' user-reference column(s) registered.') FROM UserReferenceRegistry WHERE Enabled = TRUE));

    -- Diagnostic result set for a human to eyeball before destructive steps run.
    SELECT * FROM UserReferenceRegistry WHERE Enabled = TRUE ORDER BY DiscoveryMethod, TableName, ColumnName;
END$$
DELIMITER ;

-- ---------------------------------------------------------------------
-- 5. sp_create_user_mapping
--    Builds UserObfuscationMapping deterministically. Idempotent:
--    only inserts users not already mapped.
-- ---------------------------------------------------------------------

DELIMITER $$
CREATE OR REPLACE PROCEDURE sp_create_user_mapping(IN p_run_id CHAR(36), IN p_salt VARCHAR(64))
BEGIN
    DECLARE v_col_len INT;
    DECLARE v_local_len INT;
    DECLARE v_remaining INT DEFAULT 0;

    -- Fit the generated value to the real column length instead of assuming one.
    SELECT CHARACTER_MAXIMUM_LENGTH INTO v_col_len
    FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'dap_User' AND COLUMN_NAME = 'UserID';

    IF v_col_len IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'dap_User.UserID column not found.';
    END IF;

    -- reserve room for '@example.invalid' (16 chars)
    SET v_local_len = GREATEST(v_col_len - 17, 8);

    -- Insert mapping for any user not yet mapped.
    --
    -- IDEMPOTENCY NOTE: on a re-run, dap_User.UserID may already HOLD an
    -- obfuscated value from a prior run (this same procedure updates it
    -- later in the orchestration). Without the extra "NOT IN (...
    -- ObfuscatedUserID)" guard below, a second run would treat that
    -- already-obfuscated value as a brand-new "original" value and
    -- re-hash it into yet another value every time it's run -- silently
    -- breaking idempotency and drifting the mapping further from the
    -- true original on every re-run. The guard makes a value that's
    -- already someone's ObfuscatedUserID ineligible to be treated as a
    -- new OriginalUserID.
    INSERT INTO UserObfuscationMapping (OriginalUserID, ObfuscatedUserID, CreatedDate)
    SELECT u.UserID,
           fn_generate_obfuscated_email(u.UserID, p_salt, 0, v_local_len),
           NOW()
    FROM dap_User u
    LEFT JOIN UserObfuscationMapping m ON m.OriginalUserID = u.UserID
    WHERE m.OriginalUserID IS NULL
      AND u.UserID IS NOT NULL
      AND u.UserID NOT IN (SELECT ObfuscatedUserID FROM UserObfuscationMapping);

    -- Collision handling: if the unique key on ObfuscatedUserID was violated
    -- for any of the just-attempted rows, they simply won't be present yet.
    -- Retry loop, escalating the attempt counter, capped to avoid infinite loop.
    SET v_remaining = (
        SELECT COUNT(*) FROM dap_User u
        LEFT JOIN UserObfuscationMapping m ON m.OriginalUserID = u.UserID
        WHERE m.OriginalUserID IS NULL AND u.UserID IS NOT NULL
          AND u.UserID NOT IN (SELECT ObfuscatedUserID FROM UserObfuscationMapping)
    );

    retry_loop: BEGIN
        DECLARE v_attempt INT DEFAULT 1;
        WHILE v_remaining > 0 AND v_attempt <= 5 DO
            INSERT IGNORE INTO UserObfuscationMapping (OriginalUserID, ObfuscatedUserID, CreatedDate)
            SELECT u.UserID,
                   fn_generate_obfuscated_email(u.UserID, p_salt, v_attempt, v_local_len),
                   NOW()
            FROM dap_User u
            LEFT JOIN UserObfuscationMapping m ON m.OriginalUserID = u.UserID
            WHERE m.OriginalUserID IS NULL AND u.UserID IS NOT NULL
              AND u.UserID NOT IN (SELECT ObfuscatedUserID FROM UserObfuscationMapping);

            SET v_remaining = (
                SELECT COUNT(*) FROM dap_User u
                LEFT JOIN UserObfuscationMapping m ON m.OriginalUserID = u.UserID
                WHERE m.OriginalUserID IS NULL AND u.UserID IS NOT NULL
                  AND u.UserID NOT IN (SELECT ObfuscatedUserID FROM UserObfuscationMapping)
            );
            SET v_attempt = v_attempt + 1;
        END WHILE;
    END retry_loop;

    IF v_remaining > 0 THEN
        CALL sp_log_step(p_run_id, 'sp_create_user_mapping', 'ERROR',
            CONCAT(v_remaining, ' user(s) could not be mapped after retries — investigate collisions.'));
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'User mapping incomplete after collision retries.';
    ELSE
        CALL sp_log_step(p_run_id, 'sp_create_user_mapping', 'OK',
            (SELECT CONCAT(COUNT(*), ' users mapped.') FROM UserObfuscationMapping));
    END IF;
END$$
DELIMITER ;

-- ---------------------------------------------------------------------
-- 6. FK management: drop constraints referencing dap_User.UserID,
--    capturing exact definitions, then restore them later.
--    This is the alternative to SET FOREIGN_KEY_CHECKS=0 — restoring
--    the constraint re-validates every row and fails loudly if broken.
-- ---------------------------------------------------------------------

DELIMITER $$
CREATE OR REPLACE PROCEDURE sp_drop_user_fk_constraints(IN p_run_id CHAR(36))
BEGIN
    DECLARE done INT DEFAULT 0;
    DECLARE v_constraint VARCHAR(128);
    DECLARE v_table VARCHAR(128);
    DECLARE v_cols VARCHAR(1024);
    DECLARE v_ref_table VARCHAR(128);
    DECLARE v_ref_cols VARCHAR(1024);
    DECLARE v_update_rule VARCHAR(20);
    DECLARE v_delete_rule VARCHAR(20);
    DECLARE v_sql TEXT;

    DECLARE cur CURSOR FOR
        SELECT
            rc.CONSTRAINT_NAME, rc.TABLE_NAME,
            GROUP_CONCAT(kcu.COLUMN_NAME ORDER BY kcu.ORDINAL_POSITION),
            rc.REFERENCED_TABLE_NAME,
            GROUP_CONCAT(kcu.REFERENCED_COLUMN_NAME ORDER BY kcu.ORDINAL_POSITION),
            rc.UPDATE_RULE, rc.DELETE_RULE
        FROM information_schema.REFERENTIAL_CONSTRAINTS rc
        JOIN information_schema.KEY_COLUMN_USAGE kcu
            ON kcu.CONSTRAINT_SCHEMA = rc.CONSTRAINT_SCHEMA
           AND kcu.CONSTRAINT_NAME = rc.CONSTRAINT_NAME
           AND kcu.TABLE_NAME = rc.TABLE_NAME
        WHERE rc.CONSTRAINT_SCHEMA = DATABASE()
          AND rc.REFERENCED_TABLE_NAME = 'dap_User'
        GROUP BY rc.CONSTRAINT_NAME, rc.TABLE_NAME, rc.REFERENCED_TABLE_NAME, rc.UPDATE_RULE, rc.DELETE_RULE;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

    OPEN cur;
    read_loop: LOOP
        FETCH cur INTO v_constraint, v_table, v_cols, v_ref_table, v_ref_cols, v_update_rule, v_delete_rule;
        IF done THEN
            LEAVE read_loop;
        END IF;

        -- Skip if already backed up and not yet restored (re-run safety)
        IF NOT EXISTS (
            SELECT 1 FROM FkConstraintBackup
            WHERE ConstraintName = v_constraint AND TableName = v_table AND RestoredDate IS NULL
        ) THEN
            INSERT INTO FkConstraintBackup
                (ConstraintName, TableName, ColumnList, ReferencedTableName, ReferencedColumnList, UpdateRule, DeleteRule)
            VALUES
                (v_constraint, v_table, v_cols, v_ref_table, v_ref_cols, v_update_rule, v_delete_rule);
        END IF;

        SET v_sql = CONCAT('ALTER TABLE ', fn_quote_identifier(v_table),
                            ' DROP FOREIGN KEY ', fn_quote_identifier(v_constraint));
        SET @sql_stmt = v_sql;
        PREPARE stmt FROM @sql_stmt;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;

        CALL sp_log_step(p_run_id, 'sp_drop_user_fk_constraints', 'OK',
            CONCAT('Dropped ', v_constraint, ' on ', v_table));
    END LOOP;
    CLOSE cur;
END$$
DELIMITER ;

DELIMITER $$
CREATE OR REPLACE PROCEDURE sp_restore_user_fk_constraints(IN p_run_id CHAR(36))
BEGIN
    DECLARE done INT DEFAULT 0;
    DECLARE v_id BIGINT;
    DECLARE v_constraint VARCHAR(128);
    DECLARE v_table VARCHAR(128);
    DECLARE v_cols VARCHAR(1024);
    DECLARE v_ref_table VARCHAR(128);
    DECLARE v_ref_cols VARCHAR(1024);
    DECLARE v_update_rule VARCHAR(20);
    DECLARE v_delete_rule VARCHAR(20);
    DECLARE v_sql TEXT;

    DECLARE cur CURSOR FOR
        SELECT BackupID, ConstraintName, TableName, ColumnList, ReferencedTableName, ReferencedColumnList, UpdateRule, DeleteRule
        FROM FkConstraintBackup
        WHERE RestoredDate IS NULL;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

    OPEN cur;
    read_loop: LOOP
        FETCH cur INTO v_id, v_constraint, v_table, v_cols, v_ref_table, v_ref_cols, v_update_rule, v_delete_rule;
        IF done THEN
            LEAVE read_loop;
        END IF;

        -- Rebuild "col1`,`col2" style quoted lists from the stored CSV.
        SET v_sql = CONCAT(
            'ALTER TABLE ', fn_quote_identifier(v_table),
            ' ADD CONSTRAINT ', fn_quote_identifier(v_constraint),
            ' FOREIGN KEY (`', REPLACE(v_cols, ',', '`,`'), '`)',
            ' REFERENCES ', fn_quote_identifier(v_ref_table),
            ' (`', REPLACE(v_ref_cols, ',', '`,`'), '`)',
            ' ON UPDATE ', v_update_rule,
            ' ON DELETE ', v_delete_rule
        );

        -- This ALTER will fail with a real, actionable error if any row
        -- would violate the constraint — i.e. it doubles as a referential
        -- integrity validation step.
        SET @sql_stmt = v_sql;
        PREPARE stmt FROM @sql_stmt;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;

        UPDATE FkConstraintBackup SET RestoredDate = NOW() WHERE BackupID = v_id;

        CALL sp_log_step(p_run_id, 'sp_restore_user_fk_constraints', 'OK',
            CONCAT('Restored ', v_constraint, ' on ', v_table));
    END LOOP;
    CLOSE cur;
END$$
DELIMITER ;

-- ---------------------------------------------------------------------
-- 7. sp_obfuscate_user_references
--    Updates every column registered in UserReferenceRegistry to its
--    mapped obfuscated value. Batched to avoid huge single transactions.
-- ---------------------------------------------------------------------

DELIMITER $$
CREATE OR REPLACE PROCEDURE sp_obfuscate_user_references(IN p_run_id CHAR(36), IN p_batch_size INT)
BEGIN
    DECLARE done INT DEFAULT 0;
    DECLARE v_table VARCHAR(128);
    DECLARE v_column VARCHAR(128);
    DECLARE v_sql TEXT;
    DECLARE v_rows_affected BIGINT;

    DECLARE cur CURSOR FOR
        SELECT TableName, ColumnName FROM UserReferenceRegistry WHERE Enabled = TRUE;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

    IF p_batch_size IS NULL OR p_batch_size <= 0 THEN
        SET p_batch_size = 50000;
    END IF;

    OPEN cur;
    read_loop: LOOP
        FETCH cur INTO v_table, v_column;
        IF done THEN
            LEAVE read_loop;
        END IF;

        SET v_rows_affected = 1;
        WHILE v_rows_affected > 0 DO
            SET v_sql = CONCAT(
                'UPDATE ', fn_quote_identifier(v_table), ' t ',
                'JOIN UserObfuscationMapping m ON m.OriginalUserID = t.', fn_quote_identifier(v_column), ' ',
                'SET t.', fn_quote_identifier(v_column), ' = m.ObfuscatedUserID ',
                'WHERE t.', fn_quote_identifier(v_column), ' <> m.ObfuscatedUserID ',
                'LIMIT ', p_batch_size
            );
            SET @sql_stmt = v_sql;
            PREPARE stmt FROM @sql_stmt;
            EXECUTE stmt;
            SET v_rows_affected = ROW_COUNT();
            DEALLOCATE PREPARE stmt;
        END WHILE;

        CALL sp_log_step(p_run_id, 'sp_obfuscate_user_references', 'OK',
            CONCAT(v_table, '.', v_column, ' updated.'));
    END LOOP;
    CLOSE cur;
END$$
DELIMITER ;

-- ---------------------------------------------------------------------
-- 8. sp_obfuscate_user_table
--    Updates dap_User.UserID itself from the mapping. Run only after
--    FKs referencing it have been dropped (see orchestrator).
-- ---------------------------------------------------------------------

DELIMITER $$
CREATE OR REPLACE PROCEDURE sp_obfuscate_user_table(IN p_run_id CHAR(36))
BEGIN
    UPDATE dap_User u
    JOIN UserObfuscationMapping m ON m.OriginalUserID = u.UserID
    SET u.UserID = m.ObfuscatedUserID
    WHERE u.UserID <> m.ObfuscatedUserID;

    CALL sp_log_step(p_run_id, 'sp_obfuscate_user_table', 'OK',
        CONCAT(ROW_COUNT(), ' dap_User row(s) updated.'));
END$$
DELIMITER ;

-- ---------------------------------------------------------------------
-- 9. sp_obfuscate_configured_columns
--    Dynamic dispatch over ObfuscationConfig. Each PII column is joined
--    back to dap_User via the same user-reference chain so replacement
--    values are keyed off the OWNING USER, not the raw string value —
--    satisfying "John Smith / John Brown / John Taylor" independence.
--
--    Assumption: every table carrying PII columns also carries a
--    UserID-typed column (itself, or via UserReferenceRegistry) that
--    identifies the owning user, used as the deterministic seed. If a
--    table has no such column, its own primary key is used as the seed
--    instead (still deterministic, just not shared across tables).
-- ---------------------------------------------------------------------

DELIMITER $$
CREATE OR REPLACE PROCEDURE sp_obfuscate_configured_columns(IN p_run_id CHAR(36), IN p_batch_size INT)
BEGIN
    DECLARE done INT DEFAULT 0;
    DECLARE v_table VARCHAR(128);
    DECLARE v_column VARCHAR(128);
    DECLARE v_type VARCHAR(50);
    DECLARE v_static VARCHAR(255);
    DECLARE v_pk_col VARCHAR(128);
    DECLARE v_col_len INT;
    DECLARE v_sql TEXT;
    DECLARE v_rows_affected BIGINT;
    DECLARE v_seed_expr VARCHAR(256);

    DECLARE cur CURSOR FOR
        SELECT TableName, ColumnName, ObfuscationType, StaticValue
        FROM ObfuscationConfig WHERE Enabled = TRUE;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

    IF p_batch_size IS NULL OR p_batch_size <= 0 THEN
        SET p_batch_size = 50000;
    END IF;

    OPEN cur;
    read_loop: LOOP
        FETCH cur INTO v_table, v_column, v_type, v_static;
        IF done THEN
            LEAVE read_loop;
        END IF;

        -- Determine a deterministic per-row seed: prefer a user-reference
        -- column on the same table if one is registered, else fall back
        -- to the table's own primary key column.
        --
        -- NOTE: these use SET (subquery) rather than SELECT ... INTO on
        -- purpose. A SELECT ... INTO that matches zero rows raises a
        -- NOT FOUND condition, and the CONTINUE HANDLER FOR NOT FOUND
        -- declared above for the cursor would catch THAT too (handlers
        -- are scoped to the whole block, not just the cursor's FETCH),
        -- silently ending the outer loop after the first "not found"
        -- lookup. SET (subquery) simply yields NULL on no match instead.
        -- When a table has more than one registered user-reference column
        -- (e.g. its own "UserID"/owner column AND an audit column like
        -- "CreatedBy"), prefer an FK-discovered column over a
        -- naming-convention one. An FK column typically represents "this
        -- row IS/belongs to this user"; a CreatedBy/ModifiedBy column
        -- only records who acted on it. Seeding PII off the wrong one
        -- would incorrectly collapse different row-owners who merely
        -- share a creator onto the same synthetic identity.
        SET v_pk_col = (
            SELECT ColumnName FROM UserReferenceRegistry
            WHERE TableName = v_table AND Enabled = TRUE
            ORDER BY (DiscoveryMethod = 'FOREIGN_KEY') DESC, ColumnName
            LIMIT 1
        );

        IF v_pk_col IS NULL THEN
            SET v_pk_col = (
                SELECT kcu.COLUMN_NAME
                FROM information_schema.KEY_COLUMN_USAGE kcu
                JOIN information_schema.TABLE_CONSTRAINTS tc
                    ON tc.CONSTRAINT_NAME = kcu.CONSTRAINT_NAME AND tc.TABLE_SCHEMA = kcu.TABLE_SCHEMA
                WHERE kcu.TABLE_SCHEMA = DATABASE() AND kcu.TABLE_NAME = v_table
                  AND tc.CONSTRAINT_TYPE = 'PRIMARY KEY'
                LIMIT 1
            );
        END IF;

        IF v_pk_col IS NULL THEN
            CALL sp_log_step(p_run_id, 'sp_obfuscate_configured_columns', 'SKIP',
                CONCAT('No usable seed column (user reference or PK) found for ', v_table, '.', v_column));
        ELSE
            SET v_col_len = (
                SELECT CHARACTER_MAXIMUM_LENGTH FROM information_schema.COLUMNS
                WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = v_table AND COLUMN_NAME = v_column
            );

            SET v_seed_expr = CONCAT('t.', fn_quote_identifier(v_pk_col));

            SET v_rows_affected = 1;
            WHILE v_rows_affected > 0 DO
                CASE v_type
                    WHEN 'FIRST_NAME' THEN
                        SET v_sql = CONCAT(
                            'UPDATE ', fn_quote_identifier(v_table), ' t SET t.', fn_quote_identifier(v_column),
                            ' = fn_synthetic_first_name(CAST(', v_seed_expr, ' AS CHAR)) ',
                            'WHERE t.', fn_quote_identifier(v_column), ' IS NOT NULL ',
                            'AND t.', fn_quote_identifier(v_column), ' <> fn_synthetic_first_name(CAST(', v_seed_expr, ' AS CHAR)) ',
                            'LIMIT ', p_batch_size);

                    WHEN 'LAST_NAME' THEN
                        SET v_sql = CONCAT(
                            'UPDATE ', fn_quote_identifier(v_table), ' t SET t.', fn_quote_identifier(v_column),
                            ' = fn_synthetic_last_name(CAST(', v_seed_expr, ' AS CHAR)) ',
                            'WHERE t.', fn_quote_identifier(v_column), ' IS NOT NULL ',
                            'AND t.', fn_quote_identifier(v_column), ' <> fn_synthetic_last_name(CAST(', v_seed_expr, ' AS CHAR)) ',
                            'LIMIT ', p_batch_size);

                    WHEN 'PHONE' THEN
                        SET v_sql = CONCAT(
                            'UPDATE ', fn_quote_identifier(v_table), ' t SET t.', fn_quote_identifier(v_column),
                            ' = fn_synthetic_phone(CAST(', v_seed_expr, ' AS CHAR), ', IFNULL(v_col_len, 20), ') ',
                            'WHERE t.', fn_quote_identifier(v_column), ' IS NOT NULL ',
                            'AND t.', fn_quote_identifier(v_column), ' <> fn_synthetic_phone(CAST(', v_seed_expr, ' AS CHAR), ', IFNULL(v_col_len, 20), ') ',
                            'LIMIT ', p_batch_size);

                    WHEN 'ADDRESS' THEN
                        SET v_sql = CONCAT(
                            'UPDATE ', fn_quote_identifier(v_table), ' t SET t.', fn_quote_identifier(v_column),
                            ' = LEFT(fn_synthetic_street_address(CAST(', v_seed_expr, ' AS CHAR)), ', IFNULL(v_col_len, 255), ') ',
                            'WHERE t.', fn_quote_identifier(v_column), ' IS NOT NULL ',
                            'AND t.', fn_quote_identifier(v_column), ' <> LEFT(fn_synthetic_street_address(CAST(', v_seed_expr, ' AS CHAR)), ', IFNULL(v_col_len, 255), ') ',
                            'LIMIT ', p_batch_size);

                    WHEN 'EMAIL' THEN
                        -- Secondary email columns (not the primary UserID) — static-style synthetic value.
                        SET v_sql = CONCAT(
                            'UPDATE ', fn_quote_identifier(v_table), ' t SET t.', fn_quote_identifier(v_column),
                            ' = CONCAT(''user'', ', v_seed_expr, ', ''@example.invalid'') ',
                            'WHERE t.', fn_quote_identifier(v_column), ' IS NOT NULL ',
                            'AND t.', fn_quote_identifier(v_column), ' NOT LIKE ''%@example.invalid'' ',
                            'LIMIT ', p_batch_size);

                    WHEN 'HASH' THEN
                        SET v_sql = CONCAT(
                            'UPDATE ', fn_quote_identifier(v_table), ' t SET t.', fn_quote_identifier(v_column),
                            ' = LEFT(SHA2(t.', fn_quote_identifier(v_column), ', 256), ', IFNULL(v_col_len, 64), ') ',
                            'WHERE t.', fn_quote_identifier(v_column), ' IS NOT NULL ',
                            'LIMIT ', p_batch_size);
                        -- Note: HASH is one-way and not idempotency-guarded the same way
                        -- (re-hashing an already-hashed value is harmless but not a no-op);
                        -- prefer running HASH columns only once, or track state separately.

                    WHEN 'STATIC' THEN
                        SET v_sql = CONCAT(
                            'UPDATE ', fn_quote_identifier(v_table), ' t SET t.', fn_quote_identifier(v_column),
                            ' = ', QUOTE(LEFT(IFNULL(v_static, ''), IFNULL(v_col_len, 255))), ' ',
                            'WHERE t.', fn_quote_identifier(v_column), ' IS NOT NULL ',
                            'AND t.', fn_quote_identifier(v_column), ' <> ', QUOTE(LEFT(IFNULL(v_static, ''), IFNULL(v_col_len, 255))), ' ',
                            'LIMIT ', p_batch_size);

                    ELSE
                        SET v_sql = NULL;
                END CASE;

                IF v_sql IS NULL THEN
                    CALL sp_log_step(p_run_id, 'sp_obfuscate_configured_columns', 'SKIP',
                        CONCAT('Unknown ObfuscationType "', v_type, '" for ', v_table, '.', v_column));
                    SET v_rows_affected = 0;
                ELSE
                    SET @sql_stmt = v_sql;
                    PREPARE stmt FROM @sql_stmt;
                    EXECUTE stmt;
                    SET v_rows_affected = ROW_COUNT();
                    DEALLOCATE PREPARE stmt;
                END IF;
            END WHILE;

            CALL sp_log_step(p_run_id, 'sp_obfuscate_configured_columns', 'OK',
                CONCAT(v_table, '.', v_column, ' (', v_type, ') processed.'));
        END IF;

        SET v_pk_col = NULL; -- reset for next loop iteration
    END LOOP;
    CLOSE cur;
END$$
DELIMITER ;

-- ---------------------------------------------------------------------
-- 10. sp_validate_obfuscation
--     Post-run checks: orphaned FK-style references, row-count
--     reconciliation, residual-PII spot checks.
-- ---------------------------------------------------------------------

DELIMITER $$
CREATE OR REPLACE PROCEDURE sp_validate_obfuscation(IN p_run_id CHAR(36))
BEGIN
    DECLARE v_unmapped_refs BIGINT DEFAULT 0;
    DECLARE done INT DEFAULT 0;
    DECLARE v_table VARCHAR(128);
    DECLARE v_column VARCHAR(128);
    DECLARE v_sql TEXT;
    DECLARE v_cnt BIGINT;

    DECLARE cur CURSOR FOR
        SELECT TableName, ColumnName FROM UserReferenceRegistry WHERE Enabled = TRUE;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = 1;

    -- 10a. Every user-reference column value should now exist as an
    -- ObfuscatedUserID in the mapping table (or be NULL).
    OPEN cur;
    read_loop: LOOP
        FETCH cur INTO v_table, v_column;
        IF done THEN
            LEAVE read_loop;
        END IF;

        SET v_sql = CONCAT(
            'SELECT COUNT(*) INTO @cnt FROM ', fn_quote_identifier(v_table), ' t ',
            'LEFT JOIN UserObfuscationMapping m ON m.ObfuscatedUserID = t.', fn_quote_identifier(v_column), ' ',
            'WHERE t.', fn_quote_identifier(v_column), ' IS NOT NULL AND m.ObfuscatedUserID IS NULL'
        );
        SET @sql_stmt = v_sql;
        PREPARE stmt FROM @sql_stmt;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
        SET v_cnt = @cnt;

        IF v_cnt > 0 THEN
            SET v_unmapped_refs = v_unmapped_refs + v_cnt;
            CALL sp_log_step(p_run_id, 'sp_validate_obfuscation', 'ERROR',
                CONCAT(v_cnt, ' unmapped/orphaned value(s) in ', v_table, '.', v_column));
        END IF;
    END LOOP;
    CLOSE cur;

    -- 10b. Row count reconciliation on dap_User (no rows should have been
    -- lost or gained by the process).
    CALL sp_log_step(p_run_id, 'sp_validate_obfuscation', 'OK',
        CONCAT('dap_User row count: ', (SELECT COUNT(*) FROM dap_User)));

    -- 10c. Overall status
    IF v_unmapped_refs > 0 THEN
        CALL sp_log_step(p_run_id, 'sp_validate_obfuscation', 'ERROR',
            CONCAT('Validation FAILED: ', v_unmapped_refs, ' total orphaned reference(s).'));
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Obfuscation validation failed — see ObfuscationRunLog.';
    ELSE
        CALL sp_log_step(p_run_id, 'sp_validate_obfuscation', 'OK', 'Validation passed.');
    END IF;
END$$
DELIMITER ;

-- ---------------------------------------------------------------------
-- 11. sp_purge_sensitive_staging
--     Optional cleanup: strips real PII (OriginalUserID) out of the
--     mapping table once obfuscation is validated. Only call this once
--     you're sure no further delta-sync re-run against production is
--     planned for this refresh cycle — see design doc §C.
-- ---------------------------------------------------------------------

DELIMITER $$
CREATE OR REPLACE PROCEDURE sp_purge_sensitive_staging(IN p_run_id CHAR(36))
BEGIN
    UPDATE UserObfuscationMapping SET OriginalUserID = CONCAT('purged-', ObfuscatedUserID)
    WHERE OriginalUserID NOT LIKE 'purged-%';
    -- Note: OriginalUserID is the primary key, so it can't be set to NULL;
    -- overwriting with a non-reversible placeholder achieves the same goal
    -- while keeping the table's row identity stable.

    CALL sp_log_step(p_run_id, 'sp_purge_sensitive_staging', 'OK',
        CONCAT(ROW_COUNT(), ' mapping row(s) purged of original PII.'));
END$$
DELIMITER ;

-- ---------------------------------------------------------------------
-- 12. sp_obfuscate_database
--     Master orchestrator. Single entry point.
--     p_salt        : a secret, run-specific salt (rotate per environment refresh)
--     p_batch_size  : batching for large-table UPDATEs (default 50000)
--     p_purge_after : TRUE to strip OriginalUserID after successful validation
-- ---------------------------------------------------------------------

DELIMITER $$
CREATE OR REPLACE PROCEDURE sp_obfuscate_database(
    IN p_salt VARCHAR(64),
    IN p_batch_size INT,
    IN p_purge_after BOOLEAN
)
BEGIN
    DECLARE v_run_id CHAR(36) DEFAULT UUID();

    -- Bail out fast and loudly on any unhandled error rather than leaving
    -- the schema half-migrated with no record of why.
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        CALL sp_log_step(v_run_id, 'sp_obfuscate_database', 'ERROR', 'Unhandled exception — run aborted.');
        RESIGNAL;
    END;

    CALL sp_log_step(v_run_id, 'sp_obfuscate_database', 'START', CONCAT('Run started, RunID=', v_run_id));

    CALL sp_validate_config(v_run_id);
    CALL sp_discover_user_references(v_run_id);
    CALL sp_create_user_mapping(v_run_id, p_salt);

    CALL sp_drop_user_fk_constraints(v_run_id);
    CALL sp_obfuscate_user_references(v_run_id, p_batch_size);
    CALL sp_obfuscate_user_table(v_run_id);
    CALL sp_restore_user_fk_constraints(v_run_id); -- re-validates FKs as a side effect

    CALL sp_obfuscate_configured_columns(v_run_id, p_batch_size);

    CALL sp_validate_obfuscation(v_run_id);

    IF p_purge_after THEN
        CALL sp_purge_sensitive_staging(v_run_id);
    END IF;

    CALL sp_log_step(v_run_id, 'sp_obfuscate_database', 'OK', 'Run completed successfully.');

    SELECT v_run_id AS RunID;
END$$
DELIMITER ;

-- =====================================================================
-- Example configuration inserts (adjust to your real column inventory)
-- =====================================================================
-- INSERT INTO ObfuscationConfig (TableName, ColumnName, ObfuscationType) VALUES
--   ('dap_User',  'FirstName',    'FIRST_NAME'),
--   ('dap_User',  'LastName',     'LAST_NAME'),
--   ('dap_User',  'PhoneNumber',  'PHONE'),
--   ('dap_User',  'Address',      'ADDRESS'),
--   ('dap_Actor', 'FirstName',    'FIRST_NAME'),
--   ('dap_Actor', 'LastName',     'LAST_NAME'),
--   ('dap_Actor', 'PhoneNumber',  'PHONE'),
--   ('dap_Actor', 'Address',      'ADDRESS');

-- =====================================================================
-- Example execution
-- =====================================================================
-- CALL sp_obfuscate_database('CHANGE-THIS-SECRET-SALT-PER-ENVIRONMENT', 50000, FALSE);
-- SELECT * FROM ObfuscationRunLog ORDER BY LogID;
