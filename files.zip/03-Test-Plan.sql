-- =====================================================================
-- Test Plan — Database-Side Data Obfuscation Framework
-- Run these against a disposable copy of the lower environment (or a
-- small synthetic sample schema) BEFORE running against the real refresh.
-- =====================================================================

-- ---------------------------------------------------------------------
-- TEST 0: Minimal fixture (skip if testing against a real lower-env copy)
-- ---------------------------------------------------------------------
-- CREATE TABLE dap_User (
--     UserID      VARCHAR(255) PRIMARY KEY,
--     FirstName   VARCHAR(50),
--     LastName    VARCHAR(50),
--     PhoneNumber VARCHAR(20),
--     Address     VARCHAR(255)
-- );
-- CREATE TABLE dap_Actor (
--     ActorID     BIGINT PRIMARY KEY AUTO_INCREMENT,
--     UserID      VARCHAR(255),
--     CreatedBy   VARCHAR(255),
--     FirstName   VARCHAR(50),
--     LastName    VARCHAR(50),
--     CONSTRAINT FK_Actor_User FOREIGN KEY (UserID) REFERENCES dap_User(UserID)
-- );
-- INSERT INTO dap_User (UserID, FirstName, LastName, PhoneNumber, Address) VALUES
--   ('john@test.com',  'John',  'Smith',  '0412345678', '1 Real Street'),
--   ('jane@test.com',  'Jane',  'Smith',  '0498765432', '2 Real Street'),
--   ('mark@test.com',  'Mark',  'Smith',  '0411112222', '3 Real Street');
-- INSERT INTO dap_Actor (UserID, CreatedBy, FirstName, LastName) VALUES
--   ('john@test.com', 'john@test.com', 'John', 'Smith'),
--   ('jane@test.com', 'john@test.com', 'Jane', 'Smith');
-- INSERT INTO ObfuscationConfig (TableName, ColumnName, ObfuscationType) VALUES
--   ('dap_User',  'FirstName', 'FIRST_NAME'), ('dap_User',  'LastName', 'LAST_NAME'),
--   ('dap_User',  'PhoneNumber','PHONE'),     ('dap_User',  'Address',  'ADDRESS'),
--   ('dap_Actor', 'FirstName', 'FIRST_NAME'), ('dap_Actor', 'LastName', 'LAST_NAME');

-- ---------------------------------------------------------------------
-- TEST 1: Deterministic UserID mapping
--   Same input -> same output, every time.
-- ---------------------------------------------------------------------
SELECT
    fn_generate_obfuscated_email('john@test.com', 'test-salt', 0, 40) AS run_1,
    fn_generate_obfuscated_email('john@test.com', 'test-salt', 0, 40) AS run_2,
    fn_generate_obfuscated_email('john@test.com', 'test-salt', 0, 40) =
    fn_generate_obfuscated_email('john@test.com', 'test-salt', 0, 40) AS is_deterministic;
-- EXPECT: run_1 = run_2, is_deterministic = 1

-- Different input -> (near-certainly) different output.
SELECT
    fn_generate_obfuscated_email('john@test.com', 'test-salt', 0, 40) <>
    fn_generate_obfuscated_email('jane@test.com', 'test-salt', 0, 40) AS differs_by_input;
-- EXPECT: differs_by_input = 1

-- ---------------------------------------------------------------------
-- TEST 2: Full run + referential integrity
-- ---------------------------------------------------------------------
CALL sp_obfuscate_database('test-salt-001', 10000, FALSE);

-- No dap_Actor.UserID should be left pointing at a non-existent dap_User.UserID
SELECT COUNT(*) AS orphaned_actor_rows
FROM dap_Actor a
LEFT JOIN dap_User u ON u.UserID = a.UserID
WHERE a.UserID IS NOT NULL AND u.UserID IS NULL;
-- EXPECT: 0

-- The FK constraint itself must exist again post-run (proves restore succeeded)
SELECT COUNT(*) AS fk_restored
FROM information_schema.TABLE_CONSTRAINTS
WHERE CONSTRAINT_SCHEMA = DATABASE()
  AND TABLE_NAME = 'dap_Actor'
  AND CONSTRAINT_NAME = 'FK_Actor_User'
  AND CONSTRAINT_TYPE = 'FOREIGN KEY';
-- EXPECT: 1

-- ---------------------------------------------------------------------
-- TEST 3: Consistent mapping across tables
--   dap_User.UserID and dap_Actor.CreatedBy that originally held the
--   same email must hold the same obfuscated email afterward.
-- ---------------------------------------------------------------------
SELECT
    u.UserID AS user_table_value,
    a.CreatedBy AS actor_created_by_value,
    (u.UserID = a.CreatedBy) AS values_match
FROM dap_User u
JOIN dap_Actor a ON a.CreatedBy = u.UserID;
-- EXPECT: values_match = 1 for every row (both now hold the SAME obfuscated email)

-- ---------------------------------------------------------------------
-- TEST 4: PII replacement — no original values remain
-- ---------------------------------------------------------------------
SELECT COUNT(*) AS remaining_real_names
FROM dap_User
WHERE FirstName IN ('John','Jane','Mark') OR LastName = 'Smith';
-- EXPECT: 0

SELECT COUNT(*) AS remaining_real_phones
FROM dap_User
WHERE PhoneNumber IN ('0412345678','0498765432','0411112222');
-- EXPECT: 0

-- ---------------------------------------------------------------------
-- TEST 5: Same real first name -> independent synthetic identities
--   John Smith / Jane Smith / Mark Smith share LastName 'Smith' but are
--   different users; their synthetic LastName need not be identical,
--   and critically, two DIFFERENT users sharing a first name should not
--   be forced into the same synthetic (name, phone, address) bundle.
-- ---------------------------------------------------------------------
SELECT UserID, FirstName, LastName FROM dap_User ORDER BY UserID;
-- EXPECT: manually confirm the three rows do not all show identical
-- synthetic FirstName/LastName pairs purely because they started as "Smith".

-- ---------------------------------------------------------------------
-- TEST 6: Idempotency — running twice produces no further change
-- ---------------------------------------------------------------------
SELECT SHA2(GROUP_CONCAT(UserID, FirstName, LastName, PhoneNumber, Address ORDER BY UserID), 256) AS state_before
FROM dap_User;
-- (capture this value)

CALL sp_obfuscate_database('test-salt-001', 10000, FALSE);

SELECT SHA2(GROUP_CONCAT(UserID, FirstName, LastName, PhoneNumber, Address ORDER BY UserID), 256) AS state_after
FROM dap_User;
-- EXPECT: state_after = state_before (second run is a no-op on already-obfuscated data)

-- ---------------------------------------------------------------------
-- TEST 7: Collision handling (synthetic scenario)
--   Force a collision by pre-inserting a mapping row whose
--   ObfuscatedUserID equals what attempt 0 would generate for a new
--   user, then confirm the retry logic (attempt 1+) produces a
--   different, still-deterministic value instead of failing.
-- ---------------------------------------------------------------------
-- SET @collide_target = fn_generate_obfuscated_email('newuser@test.com', 'test-salt-001', 0, 40);
-- INSERT INTO UserObfuscationMapping (OriginalUserID, ObfuscatedUserID, CreatedDate)
--   VALUES ('someone-else@test.com', @collide_target, NOW());
-- INSERT INTO dap_User (UserID, FirstName, LastName) VALUES ('newuser@test.com', 'New', 'User');
-- CALL sp_create_user_mapping(UUID(), 'test-salt-001');
-- SELECT * FROM UserObfuscationMapping WHERE OriginalUserID = 'newuser@test.com';
-- EXPECT: a row exists, with ObfuscatedUserID <> @collide_target (attempt 1 value used)

-- ---------------------------------------------------------------------
-- TEST 8: Failure handling — bad config is rejected before any data changes
-- ---------------------------------------------------------------------
-- INSERT INTO ObfuscationConfig (TableName, ColumnName, ObfuscationType)
--   VALUES ('dap_User', 'NoSuchColumn', 'STATIC');
-- CALL sp_obfuscate_database('test-salt-002', 10000, FALSE);
-- EXPECT: procedure raises SQLSTATE 45000 from sp_validate_config, and
-- ObfuscationRunLog shows an ERROR row for sp_validate_config with no
-- subsequent OK rows for later steps (i.e. it stopped before mutating data).
-- DELETE FROM ObfuscationConfig WHERE ColumnName = 'NoSuchColumn'; -- cleanup

-- ---------------------------------------------------------------------
-- TEST 9: Validation catches a deliberately broken state
-- ---------------------------------------------------------------------
-- INSERT INTO dap_Actor (UserID, CreatedBy, FirstName, LastName)
--   VALUES ('nonexistent-obfuscated-value@example.invalid', NULL, 'X', 'Y');
-- CALL sp_validate_obfuscation(UUID());
-- EXPECT: SQLSTATE 45000 raised, ObfuscationRunLog shows the orphan count for dap_Actor.UserID.
-- DELETE FROM dap_Actor WHERE UserID = 'nonexistent-obfuscated-value@example.invalid'; -- cleanup

-- ---------------------------------------------------------------------
-- Review the full run history at any point:
-- ---------------------------------------------------------------------
SELECT * FROM ObfuscationRunLog ORDER BY LogID;
